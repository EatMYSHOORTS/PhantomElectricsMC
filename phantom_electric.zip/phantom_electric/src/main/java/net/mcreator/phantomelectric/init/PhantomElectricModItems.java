
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.phantomelectric.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.phantomelectric.item.PhantomFuelRodItem;
import net.mcreator.phantomelectric.item.PhantomFuelItem;
import net.mcreator.phantomelectric.PhantomElectricMod;

public class PhantomElectricModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, PhantomElectricMod.MODID);
	public static final RegistryObject<Item> PHANTOM_FUEL = REGISTRY.register("phantom_fuel", () -> new PhantomFuelItem());
	public static final RegistryObject<Item> PHANTOM_FUEL_ROD = REGISTRY.register("phantom_fuel_rod", () -> new PhantomFuelRodItem());
}
