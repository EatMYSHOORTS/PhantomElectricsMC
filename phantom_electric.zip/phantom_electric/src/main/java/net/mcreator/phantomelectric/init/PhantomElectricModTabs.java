
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.phantomelectric.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.phantomelectric.PhantomElectricMod;

public class PhantomElectricModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PhantomElectricMod.MODID);
	public static final RegistryObject<CreativeModeTab> PHANTOM_ELECTRICS_TAB_FUEL = REGISTRY.register("phantom_electrics_tab_fuel",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.phantom_electric.phantom_electrics_tab_fuel")).icon(() -> new ItemStack(Items.POWDER_SNOW_BUCKET)).displayItems((parameters, tabData) -> {
				tabData.accept(PhantomElectricModItems.PHANTOM_FUEL.get());
				tabData.accept(PhantomElectricModItems.PHANTOM_FUEL_ROD.get());
			}).withSearchBar().build());
}
